import random
import torch
import numpy as np
from collections import namedtuple

# Taken from
# https://github.com/pytorch/tutorials/blob/master/Reinforcement%20(Q-)Learning%20with%20PyTorch.ipynb

Transition = namedtuple('Transition', ('state', 'action', 'mask', 'next_state',
                                       'reward'))


class Memory(object):
    def __init__(self):
        self.memory = []

    def push(self, *args):
        """Saves a transition."""
        self.memory.append(Transition(*args))

    def sample(self):
        return Transition(*zip(*self.memory))

    def __len__(self):
        return len(self.memory)


if __name__ == '__main__':
    memory = Memory()
    memory.push(np.array([1,2]),np.array([0,4,5,6]),1,np.array([3,4]), 1)
    memory.push(np.array([5,6]),np.array([1,1,5,8]), 0, np.array([7,8]), 5)
    memory.push(np.array([1, 2]), np.array([0,8,1,8]), 1, np.array([3, 4]), 1)
    memory.push(np.array([5, 6]), np.array([2,4,8,2]), 0, np.array([7, 8]), 5)
    memory.push(np.array([1, 2]), np.array([3,9,4,4]), 1, np.array([3, 4]), 1)
    memory.push(np.array([5, 6]), np.array([1,4,2,8]), 0, np.array([7, 8]), 5)
    sample = memory.sample()
    print(sample)
    print('state:\n',torch.from_numpy(np.array(sample.state)))
    print('action:\n',torch.from_numpy(np.array(sample.action)))
    print('mask:\n',torch.from_numpy(np.array(sample.mask)))
    reward = torch.from_numpy(np.array(sample.reward))
    print('reward:\n',reward)
    print(reward.size(0))