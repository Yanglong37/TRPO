import torch
import torch.autograd as autograd
import torch.nn as nn
import numpy as np

# 策略网络的构建
class Policy(nn.Module):
    def __init__(self,num_outputs):
        super(Policy, self).__init__()
        self.cnn_layers = nn.Sequential(nn.Conv2d(1,10,kernel_size=2,stride=1,padding=0),
                                        nn.Tanh()
                                        )
        self.linear_layers = nn.Sequential(nn.Linear(250,20),
                                           nn.Tanh(),
                                           nn.Linear(20,num_outputs)
                                           )
        self.action_log_std = nn.Parameter(torch.zeros(1, num_outputs))

    def forward(self,x):
        x = self.cnn_layers(x)
        x = x.view(x.size(0),-1)
        x = self.linear_layers(x)
        action_log_std = self.action_log_std.expand_as(x)
        action_std = torch.exp(action_log_std)

        return  x, action_log_std,action_std


class Value(nn.Module):
    def __init__(self):
        super(Value,self).__init__()
        self.cnn_layers = nn.Sequential(nn.Conv2d(1,10,kernel_size=2,stride=1,padding=0),
                                        nn.Tanh(),
                                        )
        self.linear_layers = nn.Sequential(nn.Linear(250,20),
                                           nn.Tanh(),
                                           nn.Linear(20,1)
                                           )
    def forward(self,x):
        x = self.cnn_layers(x)
        x = x.view(x.size()[0],-1)
        x = self.linear_layers(x)

        return x

# class Policy(nn.Module):
#     def __init__(self, num_inputs, num_outputs):
#         super(Policy, self).__init__()
#         self.affine1 = nn.Linear(num_inputs, 10)
#         self.affine2 = nn.Linear(10, 10)
#
#         self.action_mean = nn.Linear(10, num_outputs)
#         self.action_mean.weight.data.mul_(0.1)
#         self.action_mean.bias.data.mul_(0.0)
#
#         # 将一个不可训练的类型Tensor转换成可以训练的类型parameter并将这个parameter绑定到这个module里面
#         self.action_log_std = nn.Parameter(torch.zeros(1, num_outputs))
#
#         self.saved_actions = []
#         self.rewards = []
#         self.final_value = 0
#
#     # 前向传播
#     def forward(self, x):
#         x = torch.tanh(self.affine1(x))
#         x = torch.tanh(self.affine2(x))
#
#         # 将x传入到self.action_mean()当中去，计算网络输出。
#         action_mean = self.action_mean(x)
#         # expand_as这个函数就是将self.action_log_std扩充为action_mean
#         action_log_std = self.action_log_std.expand_as(action_mean)
#         action_std = torch.exp(action_log_std)
#
#         return action_mean, action_log_std, action_std
#
#
# class Value(nn.Module):
#     def __init__(self, num_inputs):
#         super(Value, self).__init__()
#         self.affine1 = nn.Linear(num_inputs, 10)
#         self.affine2 = nn.Linear(10, 10)
#         self.value_head = nn.Linear(10, 1)
#         self.value_head.weight.data.mul_(0.1)
#         self.value_head.bias.data.mul_(0.0)
#
#     def forward(self, x):
#         x = torch.tanh(self.affine1(x))
#         x = torch.tanh(self.affine2(x))
#
#         # 计算网络输出。
#         state_values = self.value_head(x)
#         return state_values
#



if __name__ =='__main__':
    net = Value()
    print(net)
    # data = torch.from_numpy(np.random.randint(1,200,size=(32,4))).float()
    # print(data.size())
    # print(net(autograd.Variable(data)))
    print(net(autograd.Variable(torch.randn(1,1,6,6))))